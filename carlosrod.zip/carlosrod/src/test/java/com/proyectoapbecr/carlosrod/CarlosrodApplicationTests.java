package com.proyectoapbecr.carlosrod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarlosrodApplicationTests {

	@Test
	void contextLoads() {
	}

}

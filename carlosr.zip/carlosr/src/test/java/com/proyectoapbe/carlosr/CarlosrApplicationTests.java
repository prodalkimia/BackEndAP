package com.proyectoapbe.carlosr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarlosrApplicationTests {

	@Test
	void contextLoads() {
	}

}
